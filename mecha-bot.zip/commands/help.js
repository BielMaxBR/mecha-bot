module.exports = ({message}) =>{
  message.reply('ta perdido? liga pro batman')
}