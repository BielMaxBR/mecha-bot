module.exports = async function({message}) {
  await message.channel.send("https://tenor.com/view/amogus-among-us-meme-impostor-sus-gif-20948491")
}